# agent.py
# CLI Q&A Agent using fine-tuned LoRA adapter

import os
import sys
import json
import datetime
import re
from transformers import AutoTokenizer, pipeline
from peft import AutoPeftModelForCausalLM

BASE_MODEL = "microsoft/phi-2"
ADAPTER_PATH = "adapter/qlora_adapter"

# Load tokenizer
print("[INFO] Loading tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(ADAPTER_PATH)
tokenizer.pad_token = tokenizer.eos_token

# Load full model with LoRA adapter pre-attached
print("[INFO] Loading LoRA adapter with base model...")
model = AutoPeftModelForCausalLM.from_pretrained(ADAPTER_PATH, device_map="auto", torch_dtype="float32")

# Set up inference pipeline
gen_pipeline = pipeline("text-generation", model=model, tokenizer=tokenizer)

# Input handling
if len(sys.argv) < 2:
    print("Usage: python agent.py \"<your CLI instruction>\"")
    sys.exit(1)

instruction = sys.argv[1]
print(f"\n[USER INSTRUCTION] {instruction}\n")

# Generate response
prompt = f"Instruction: {instruction}\nOutput:"
output = gen_pipeline(prompt, max_new_tokens=100, temperature=0.7)[0]['generated_text']

# Print response
print("[AGENT RESPONSE]")
for line in output.split('\n')[1:]:
    print("- " + line.strip())

# Optional shell command
lines = output.split("\n")
shell_cmd = lines[1] if len(lines) > 1 else ""
if re.match(r"^\s*(ls|cd|mkdir|git|tar|rm|touch|cat|echo)\b", shell_cmd):
    print(f"\n[DRY RUN] Would execute: {shell_cmd.strip()}")

# Log
os.makedirs("logs", exist_ok=True)
trace = {
    "timestamp": datetime.datetime.now().isoformat(),
    "instruction": instruction,
    "response": output,
    "dry_run_cmd": shell_cmd.strip() if shell_cmd else None,
}
with open("logs/trace.jsonl", "a") as logf:
    logf.write(json.dumps(trace) + "\n")